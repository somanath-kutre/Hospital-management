<div  class="bg-red-500 text-white font-bold px-4 py-2 my-2 rounded fadealert">
    {{ $slot }}
</div>