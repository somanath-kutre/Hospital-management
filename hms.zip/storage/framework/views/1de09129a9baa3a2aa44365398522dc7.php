<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

    

    <div class="py-5">
        <div class="mx-auto sm:px-6 lg:px-8 py-5 ">
            <p class="text-2xl font-medium text-red-900 ">Patients</p>
            <div class="border-b border-red-900 mt-2"></div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 mx-auto my-3 sm:px-6 lg:px-8">
            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Total Patients</h2>
                <p class="mt-2 font-medium text-2xl"> <?php echo e($tot_patients); ?></p>
            </div>

            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Total OPD Registers</h2>
                <p class="mt-2 font-medium text-2xl"><?php echo e($opd_counts); ?></p>
            </div>

            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Total IPD Registers</h2>
                <p class="mt-2 font-medium text-2xl"><?php echo e($ipd_counts); ?></p>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="mx-auto sm:px-6 lg:px-8 py-5  rounded">
            <p class="text-2xl font-medium text-red-900 ">Payments</p>
            <div class="border-b border-red-900 mt-2"></div>
           
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4 mx-auto my-3 sm:px-6 lg:px-8">
            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Today Total Payment</h2>
                <p class="mt-2 font-medium text-2xl"><span class="text-xl">&#8377;</span> <?php echo e($total_cash); ?></p>
            </div>

            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Today Total Payment In <strong>Cash</strong></h2>
                <p class="mt-2 font-medium text-2xl"><span class="text-xl">&#8377;</span> <?php echo e($tot_cash); ?></p>
            </div>

            <div class="bg-emerald-100 py-4 rounded text-center shadow">
                <h2 class="font-medium text-emerald-900 text-lg">Today Total Payment In <strong>UPI</strong></h2>
                <p class="mt-2 font-medium text-2xl"><span class="text-xl">&#8377;</span> <?php echo e($upi); ?></p>
            </div>
        </div>
    </div>

 
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\HMS\hms\resources\views/pages/receptionist/dashboard.blade.php ENDPATH**/ ?>