<link rel="stylesheet" href="<?php echo e(asset('css/richtext.min.css')); ?>">
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <div>
        <div class="uppercase text-xl text-green-800 p-5 rounded-md  bg-green-200 dark:bg-gray-700 dark:text-gray-400">
            opd prescriptions
        </div>
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class=" text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        SL no
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Patient Name
                    </th>
                    <th scope="col" class="px-6 py-3">
                        type
                    </th>
                    <th scope="col" class="px-6 py-3">
                        date
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $n = 0;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <?php echo e($n = $n + 1); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->patient_name); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->type); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->admission_date); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-green-800 prescrb','value' => ''.e($patient->aid).'','dataModalTarget' => 'AddbillModal','dataModalToggle' => 'AddbillModal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-green-800 prescrb','value' => ''.e($patient->aid).'','data-modal-target' => 'AddbillModal','data-modal-toggle' => 'AddbillModal']); ?>Prescribe <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <?php $__currentLoopData = $available; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avlble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($patient->aid == $avlble->admission_id): ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-red-800 pre_print','value' => ''.e($patient->aid).'','dataModalTarget' => 'print_precri','dataModalToggle' => 'print_precri']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-red-800 pre_print','value' => ''.e($patient->aid).'','data-modal-target' => 'print_precri','data-modal-toggle' => 'print_precri']); ?>print <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <hr>
        </table>
    </div>
    

    


    
    <div>
        <div class="uppercase text-xl text-blue-800 p-5 rounded-md  bg-blue-200 dark:bg-gray-700 dark:text-gray-400">
            ipd discharge summary
        </div>
        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead class=" text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        SL no
                    </th>
                    <th scope="col" class="px-6 py-3">
                      Admission ID
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Patient Name
                    </th>

                    <th scope="col" class="px-6 py-3">
                        type
                    </th>
                    <th scope="col" class="px-6 py-3">
                        date
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $n = 0;
                ?>
                <?php $__currentLoopData = $ipd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <?php echo e($n = $n + 1); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->aid); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->patient_name); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->type); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($patient->admission_date); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['id' => 'btn-summary','class' => 'bg-blue-800 btn-summary','value' => ''.e($patient->aid).'','dataModalTarget' => 'AddPrecription','dataModalToggle' => 'AddPrecription']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'btn-summary','class' => 'bg-blue-800 btn-summary','value' => ''.e($patient->aid).'','data-modal-target' => 'AddPrecription','data-modal-toggle' => 'AddPrecription']); ?>Summary <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            <?php $__currentLoopData = $ipd_available; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avlble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($patient->aid == $avlble->admission_id): ?>
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-red-800 print_sum','value' => ''.e($patient->aid).'','dataModalTarget' => 'print_summary','dataModalToggle' => 'print_summary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-red-800 print_sum','value' => ''.e($patient->aid).'','data-modal-target' => 'print_summary','data-modal-toggle' => 'print_summary']); ?>print <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <hr>
        </table>
    </div>
    

    



    
    <div>
        <div id="AddbillModal" data-modal-backdrop="static" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full"
            style="background-color: #a5bcff59;">
            <div class="relative w-full max-w-3xl max-h-full">
                <!-- Modal content -->
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <!-- Modal header -->
                    <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                            Add Prescription
                        </h3>
                        <button type="button"
                            class="close-pop text-black bg-transparent bg-red-400 hover:bg-red-800 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            data-modal-hide="AddbillModal">
                            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                                viewBox="0 0 14 14">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                    </div>
                    <!-- Modal body -->
                    <div class="p-4">
                        <input type="text" id="a_id" class="a_id hidden" disabled>
                        <div class="grid grid-cols-3 gap-4">
                            <div class="name">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'name','value' => ''.e(__('Medication')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','value' => ''.e(__('Medication')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'medicine','class' => 'block mt-1 w-full medicine','type' => 'text','name' => 'medicine','value' => ''.e(old('medicine')).'','placeholder' => 'Enter Medication']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'medicine','class' => 'block mt-1 w-full medicine','type' => 'text','name' => 'medicine','value' => ''.e(old('medicine')).'','placeholder' => 'Enter Medication']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php $__errorArgs = ['medicine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-800 err_iname"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="name">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'name','value' => ''.e(__('Strenth')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','value' => ''.e(__('Strenth')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'strenth','class' => 'block mt-1 w-full strenth','type' => 'number','name' => 'strenth','value' => ''.e(old('strenth')).'','placeholder' => 'Enter strenth']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'strenth','class' => 'block mt-1 w-full strenth','type' => 'number','name' => 'strenth','value' => ''.e(old('strenth')).'','placeholder' => 'Enter strenth']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php $__errorArgs = ['strenth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-800 err_iname"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="pt-7 px-2">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'name','value' => ''.e(__('')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','value' => ''.e(__('')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-green-800 add_pre']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-green-800 add_pre']); ?>
                                    add
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                        </div>
                        
                    </div>

                    <textarea class="content" name="example">
                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        <div style="font-size:20px" >
                                        Name: <span class="p_name"></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div style="font-size:20px" >
                                        Age: <span class="p_age"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>

                                </tr>
                                <td>
                                    <div style="font-size:20px" >
                                    Address: <span class="p_address"></span>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size:20px" >
                                    Doctor: <span class="p_doctor"></span>
                                    </div>
                                </td>
                                </tr>
                            </tbody>
                        </table>
                            
                        <span>
                            
                            <table border="1" cellpadding="5" style="border-collapse: collapse;" class='txt-pres'>
                                <tr style="border: 2px solid black !important;padding: 5px; ">
                                    <td style="font-size:24px;border: 2px solid black !important;padding: 5px; "> Perticulars</td>
                                    <td style="font-size:24px;border: 2px solid black !important;padding: 5px; ">Qty</td>
                                </tr>
                            </table>  
                        </span>   
                        
                    </textarea>

                    <div class="py-4 px-4">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-blue-800 sub_pres']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-blue-800 sub_pres']); ?>
                            Submit
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
    

    

    
    <div>
        <div id="print_precri" data-modal-backdrop="static" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full"
            style="background-color: #a5bcff59;">
            <div class="relative w-full max-w-3xl max-h-full">
                <!-- Modal content -->
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <!-- Modal header -->
                    <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                            Patient Summary
                        </h3>
                        <button type="button"
                            class="cls-model text-black bg-transparent bg-red-400 hover:bg-red-800 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            data-modal-hide="print_precri">
                            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 14 14">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                    </div>
                    <!-- Modal body -->
                    <div class="p-6 space-y-6 pt_bill_modal" id="">
                        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                            <div class="printable" id="printable">
                                <div class="hidden">
                                    <table style="margin-bottom:30px">
                                        <tr>
                                            <th colspan="3" class="center">
                                                <h1>ASHWINI HOSPITAL</h1>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" style="text-align: center;">SHIVE SAGAR ARCADE 1264,
                                                RAMLINGKHIND
                                                ,
                                                BELGAUM - 590002 </th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Dr. S. N. Shetti. (M.s, FAIS, FIAGES)</td>
                                            <td class="bold">
                                                <div style="display:flex;">
                                                    <div>Ph. No:</div>
                                                    <div style="margin-left:5px">2429214 <br /><br />2408357</div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <table style="">
                                    <tr>
                                        <td class="bold"> Name: <strong class="pr_name"></strong></td>
                                        <td class="bold"> Age: <strong class="pr_age"></strong></td>
                                    </tr>
                                    <tr>
                                        <td class="bold p_address">Address: <strong class="pr_address"></strong></td>
                                        <td class="bold p_discharge">
                                            Doctor: <strong class="pr_doc"></strong>
                                        </td>
                                    </tr>
                                </table>
                                <br>
                                <table
                                    class="w-full border border-gray-300 text-sm text-left text-gray-500 dark:text-gray-400">
                                    <thead
                                        class="text-gray-700 border border-gray-300 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                        <tr class="border border-gray-300">
                                            <th scope="col" class="px-6">
                                                Precriptions
                                            </th>
                                            <th scope="col" class="px-6">
                                                Qty
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="pres-body">

                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- Modal footer -->
                    <div class="px-2 py-2">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'con_print','id' => 'con_print']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'con_print','id' => 'con_print']); ?>confirm <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    <div>
        <div id="AddPrecription" data-modal-backdrop="static" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full"
            style="background-color: #a5bcff59;">
            <div class="relative w-full max-w-3xl max-h-full">
                <!-- Modal content -->
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <!-- Modal header -->
                    <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                            Add Summary
                        </h3>
                        <button type="button"
                            class="close-pop text-black bg-transparent bg-red-400 hover:bg-red-800 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            data-modal-hide="AddPrecription">
                            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 14 14">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                    </div>
                    <!-- Modal body -->
                    <input type="text" id="sum_aid" class="sum_aid hidden" disabled>

                    <textarea class="content-summary" name="example">
                        <div class="summary-tab">
                        </div>
                    </textarea>

                    <div class="py-4 px-4">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-blue-800 sub_summary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-blue-800 sub_summary']); ?>
                            Submit
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
    

    

    
    <div>
        <div id="print_summary" data-modal-backdrop="static" tabindex="-1" aria-hidden="true"
            class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full"
            style="background-color: #a5bcff59;">
            <div class="relative w-full max-w-3xl max-h-full">
                <!-- Modal content -->
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <!-- Modal header -->
                    <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                        <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                            Patient Summary
                        </h3>
                        <button type="button"
                            class="cls-model text-black bg-transparent bg-red-400 hover:bg-red-800 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            data-modal-hide="print_summary">
                            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="none" viewBox="0 0 14 14">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                    </div>
                    <!-- Modal body -->
                    <div class="p-6 space-y-6 pt_bill_modal" id="">
                        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                            <div class="printable_summary" id="printable_summary">

                                <div class="hidden">
                                    <table style="margin-bottom:30px">
                                        <tr>
                                            <th colspan="3" class="center">
                                                <h1>ASHWINI HOSPITAL</h1>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th colspan="3" style="text-align: center;">SHIVE SAGAR ARCADE 1264,
                                                RAMLINGKHIND
                                                ,
                                                BELGAUM - 590002 </th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Dr. S. N. Shetti. (M.s, FAIS, FIAGES)</td>
                                            <td class="bold">
                                                <div style="display:flex;">
                                                    <div>Ph. No:</div>
                                                    <div style="margin-left:5px">2429214 <br /><br />2408357</div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <table style="">
                                    <tr>
                                        <td class="bold"> Name: <strong class="sum_name"></strong></td>
                                        <td class="bold"> Age: <strong class="sum_age"></strong></td>
                                    </tr>
                                    <tr>
                                        <td class="bold p_address">Address: <strong class="sum_address"></strong></td>
                                        <td class="bold p_discharge">
                                            Doctor: <strong class="sum_doc"></strong>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="bold p_address">D.O.A: <strong class="sum_doa"></strong></td>
                                        <td class="bold p_discharge">
                                            D.O.D: <strong class="sum_dod"></strong>
                                        </td>
                                    </tr>
                                </table>
                                <br>

                                <div
                                    style="border:1px solid black;text-align:center;padding:5px;margin:20px 200px;font-weight:bold;border-radius:5px;font-size:20px">
                                    Discharge Summary
                                </div>
                                <div class="brief-summ" style="padding: 10px;">
                                   
                                </div>
                               
                            </div>
                        </div>

                    </div>
                    <!-- Modal footer -->
                    <div class="px-2 py-2">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'summ_print','id' => 'summ_print']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'summ_print','id' => 'summ_print']); ?>confirm <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <script src="<?php echo e(asset('js/jquery.richtext.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>

    <script src="<?php echo e(asset('js/alert.js')); ?>"></script>

    <script></script>
    <script>
        $('.content').richText();

        $('.content-summary').richText();

        $(function() {
            // Function to fetch tags from the database
            function getTags(request, response) {
                $.ajax({
                    type: 'GET',
                    url: '<?php echo e(route('doc.get_medicines')); ?>', // Replace with your API or route URL
                    dataType: 'json',
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        response(data);
                        var list = response(data);
                        console.log(list);

                    }
                });
            }

            // Initialize the autocomplete widget
            $("#medicine").autocomplete({
                source: getTags // Use the getTags function as the source
            });
        });

        $(document).ready(function() {

            $(".prescrb").click(function(e) {
                e.preventDefault();
                $('#medicine').focus();
                id = $(this).val();
                $('#a_id').val(id);
                $(".sub_pres").val(id);

                // $(".p_name").html("");
                // $(".p_age").html("")
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('doc.get_prescr')); ?>",
                    data: {
                        id: id
                    },
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        if (response.msg == 'success') {
                            // prescription = response.list[1]['prescription']
                            console.log(response.patient['name']);
                            prescription = response.list
                            $(".p_name").html(response.patient['name']);
                            $(".p_age").html(response.patient['age']);
                            $(".p_address").html(response.patient['address']);
                            $(".p_doctor").html(response.patient['doctor']);
                            $.each(prescription, function(ind, val) {
                                $('.txt-pres').html(val.prescription);
                            });
                        } else if (response.msg == 'failed') {
                            $('.txt-pres').html("");
                            $(".p_name").html(response.patient['name']);
                            $(".p_age").html(response.patient['age']);
                            $(".p_address").html(response.patient['address']);
                            $(".p_doctor").html(response.patient['doctor']);
                        }
                    }
                });
            });

            $('.add_pre').click(function(e) {
                e.preventDefault();
                aid = $('.a_id').val();
                med = $('#medicine').val();
                str = $('#strenth').val();
                console.log(med, str, aid);
                $(".txt-pres").append(
                    ` <tr>
                        <td style="px-6 py-3">${med}<br>1-1-1</td>
                         <td style="px-6 py-3">${str}</td>
                        </tr>`
                );
                $('#medicine').val("");
                $('#strenth').val("");
                elements = $('.txt-pres').html();
                console.log(elements);
                // $('.txt-pres').html("");
            });

            $('.sub_pres').click(function(e) {
                e.preventDefault();
                tablets = $('.txt-pres').html();
                id = $(this).val();
                console.log(tablets, id);
                if (tablets == '') {
                    Swal.fire("There is no prescription");
                } else {
                    $.ajax({
                        type: "get",
                        url: "<?php echo e(route('doc.insert_prescription')); ?>",
                        data: {
                            id: id,
                            medicines: tablets
                        },
                        // dataType: "dataType",
                        success: function(response) {
                            Swal.fire("Prescriptions have been submitted");
                            $(".close-pop").trigger('click');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        }
                    });
                }
            });

            $(".pre_print").click(function(e) {
                e.preventDefault();
                a_id = $(this).val();
                $.ajax({
                    type: "get",
                    url: "<?php echo e(route('doc.get_pre_print')); ?>",
                    data: {
                        id: a_id
                    },
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        msg = response.msg
                        if (msg == 'success') {
                            medicines = response.tablets[0]['prescription']
                            $(".pres-body").html(medicines);
                            $('.pr_name').html(response.patient_details['name']);
                            $('.pr_age').html(response.patient_details['age']);
                            $('.pr_doc').html(response.patient_details['doctor']);
                            $('.pr_address').html(response.patient_details['address']);
                            $('#con_print').trigger('click');
                        } else if (msg == 'failed') {
                            $(".pres-body").html("");
                            $('.cls-model').trigger('click');
                            Swal.fire("there are no prescriptions")
                        }
                    }
                });
            });


            $('.btn-summary').click(function(e) {
                e.preventDefault();
                id = $(this).val();
                summary = $(".summary-tab").html();
                console.log(id);
                $(".sum_aid").val(id);

                $.ajax({
                    type: "get",
                    url: "<?php echo e(route('doc.summary')); ?>",
                    data: {
                        id: id,
                        summary: summary
                    },
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        if (response.msg == 'Sucessfull') {
                            $(".summary-tab").html(response.summary[0]['summary']);
                        } else if (response.msg == 'failed') {
                            $(".summary-tab").html(response.summary);
                        }
                    }
                });
            });

            $('.sub_summary').click(function(e) {
                e.preventDefault();
                id = $(".sum_aid").val();
                summary = $('.summary-tab').html();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                // console.log(summary);
                if (summary == '') {
                    Swal.fire('there is no summary to submit');
                } else {
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('doc.sub_sammary')); ?>",
                        data: {
                            id: id,
                            summary: summary
                        },
                        // dataType: "dataType",
                        success: function(response) {
                            Swal.fire("submitted successfully");
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        }
                    });
                }
            });



            $(".con_print").click(function(e) {
                e.preventDefault();
                console.log("clicked");
                var contentToPrint = $("#printable").html();
                // Open a new window and set its content to the div's content
                sign = `<div id="bottom-right-div">
        <h4>Signature</h4>
    </div>`;
                date = `<div id="bottom-left-div">
        <h4>Date: 08/04/2023</h4>
    </div>`
                var printWindow = window.open("");
                printWindow.document.write(`<html><head><title>Print</title>
                    <style>       
                        @media print {

            table {
                border-collapse: collapse;
                width: 100%;
                border-radius:10px;
            }

            table th, table td {
                border: 1px solid black !important;
                padding: 8px;
                text-align: left;
                
            }
            .hosp_info{
                text-align:center;
            }   
            
            .bold{
            font-weight:400;}
            .center{
            text-align: center
            }
            #bottom-right-div {
    position: fixed;
    bottom: 10px;
    right: 10px;
    padding: 10px; 
}
#bottom-left-div {
    position: fixed;
    bottom: 10px;
    left: 10px;
    padding: 10px; 
}
body {font-family: 'Poppins', sans-serif;
font-family: 'Work Sans', sans-serif; }

            /* Hide non-printable elements */
            .no-print {
                display: none;
            }
        }</style></head><body>`);


                printWindow.document.write(contentToPrint);
                printWindow.document.write(sign, date);
                printWindow.document.write('</body></html>');
                // printWindow.document.close();
                // Print the new window's content
                printWindow.print();
                printWindow.close();
                $(".cls-model").trigger('click');
            });


            $(".summ_print").click(function(e) {
                e.preventDefault();
                console.log("clicked");
                var contentToPrint = $("#printable_summary").html();
                // Create "sign" and "date" elements
                // var sign = '<div id="bottom-right-div"><h4>Signature</h4></div>';
                // var date = '<div id="bottom-left-div"><h4>Date: 08/04/2023</h4></div>';
                // Open a new window and set its content to the div's content
                var printWindow = window.open("");
                printWindow.document.write(
                    `<html><head><title>Print</title><style>@media print { table { border-collapse: collapse; width: 100%; border-radius: 10px; } table th, table td { border: 1px solid black !important; padding: 8px; text-align: left; } .hosp_info { text-align: center; } .bold { font-weight: 400; } .center { text-align: center; }  body { font-family: 'Poppins', sans-serif; font-family: 'Work Sans', sans-serif; } .no-print { display: none; } }</style></head><body>`
                );
                printWindow.document.write(contentToPrint);
                // printWindow.document.write(sign);
                // printWindow.document.write(date);
                printWindow.document.write('</body></html>');
                printWindow.document.close(); // Close HTML and body tags
                // Print the new window's content
                printWindow.print();
                printWindow.close();
            });

            $('.print_sum').click(function(e) {
                e.preventDefault();
                id = $(this).val();
                $.ajax({
                    type: "get",
                    url: "<?php echo e(route('doc.get_sum_print')); ?>",
                    data: {
                        id: id
                    },
                    // dataType: "dataType",
                    success: function(response) {
                        console.log(response.date);
                        if (response.msg == 'success') {
                            medicines = response.summary[0]['summary']
                            $(".brief-summ").html(medicines);
                            $('.sum_name').html(response.patient_details['name']);
                            $('.sum_age').html(response.patient_details['age']);
                            $('.sum_doc').html(response.patient_details['doctor']);
                            $('.sum_address').html(response.patient_details['address']);
                            $('.sum_dod').html(response.admdate);
                            $('.sum_doa').html(response.dis_date);
                            $('#summ_print').trigger('click');
                            $('.cls-model').trigger('click');
                        } else if (response.msg == 'failed') {
                            $("..brief-summ").html("");
                            $('.cls-model').trigger('click');
                            Swal.fire("there are no prescriptions")
                        }
                    }
                });

            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\HMS\hms\resources\views/pages/doctor/prescription.blade.php ENDPATH**/ ?>