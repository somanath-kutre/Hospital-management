<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => $title, 'link' => $link,'active' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => $title, 'link' => $link,'active' => false]); ?>
<?php foreach (array_filter((['title' => $title, 'link' => $link,'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
$classes = ($active)
    ? 'block pl-3 pr-4 py-2 border-l-4 border-indigo-500 text-base dark:text-blue-800 font-medium text-indigo-700 bg-indigo-50 dark:bg-blue-200 dark:text-blue-900 focus:outline-none focus:text-indigo-800 focus:bg-indigo-100 focus:border-indigo-700 transition duration-150 ease-in-out'
    : 'block pl-3 pr-4 py-2 border-l-4 border-transparent text-base  font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-200 hover:border-gray-300 focus:outline-none focus:text-gray-800 focus:bg-gray-50 focus:border-gray-300 transition duration-150 ease-in-out';
?>


<a href="<?php echo e($link); ?>" class="<?php echo e($classes); ?> flex items-center p-2 text-gray-900 hover:text-indigo-900 dark:hover:text-white rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group">
    
     
    <span class="flex-1 ml-3 whitespace-nowrap"><?php echo e($title); ?></span>
    
 </a><?php /**PATH E:\Laravel\HMS\hms\resources\views/components/sidebarlink.blade.php ENDPATH**/ ?>