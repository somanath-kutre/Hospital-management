<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="meds">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.papers.medication','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('papers.medication'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>


    <div class="p-4">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'btn-prt-meds']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-prt-meds']); ?>Print it <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>



    <script>
        $(document).ready(function() {
            print_meds();

            function print_meds() {
                var list = <?php echo $medicines; ?>;
                var p_data = <?php echo $patient_data; ?>;

                p_name = p_data[0]['patient_name'];
                p_age = p_data[0]['p_age'];
                p_reg = p_data[0]['aid'];
                opd_no = p_data[0]['opd_no'];
                p_a_date = p_data[0]['admission_date'];
                p_sex = p_data[0]['gender'];

                $('.ip_ptname').html(p_name);
                $('.ip_age').html(p_age);
                $('.opd_no').html(opd_no);
                $('.ip_reg_no').html(p_reg);
                $('.ip_date_adm').html(p_a_date);
                $('.ip_gender').html(p_sex);
                $('.ip_date').html(p_a_date);
                var n = 0;
                var currentTable = createNewTable(); // Initialize with the first table

                $.each(list, function(ind, val) {
                    var divHeight = currentTable.height();
                    console.log("Current Table Height: " + divHeight + " pixels");

                    if (divHeight > 320) {
                        currentTable = createNewTable(); // Create a new table if the height exceeds 400px
                    }

                    // If this is the first row in the new table, add the table header
                    if (currentTable.find("tbody").children().length === 0) {
                        currentTable.find("thead").append(`
  <tr id="trh" style="">
    <th style="width:10%">SL NO</th>
    <th><span style="margin-left:5px">Name Of The Drug</span></th>
    <th>Dosage</th>
    <th>Qty</th>
  </tr>
`);
                    }

                    currentTable.find(".tbody").append(`
<tr role="row">
  <td rowspan="1" colspan="1">${(n = n + 1)}</td>
  <td rowspan="1" colspan="1">${val.medicine}</td>
  <td rowspan="1" colspan="1">${val.dosage}</td>
  <td rowspan="1" colspan="1">${val.strenth}</td>
</tr>
`);
                });

                // Function to create a new table and append it to the .div-pres element
                function createNewTable() {
                    var newTable = $(
                        "<div class='main-table'><table id='customers' style='margin: 0px'><thead></thead><tbody class='tbody'></tbody></table></div>"
                    );
                    $(".div-pres").append(newTable);
                    return newTable;
                }
            }

            $('.btn-prt-meds').click(function(e) {
                e.preventDefault();
                var html = $('.meds').html();
                var printWindow = window.open("");
                printWindow.document.write(html);
                printWindow.print();
                printWindow.close();
                window.location.href = "/receptionist/patients";
            });

            trigger_print();

            function trigger_print() {
                $('.btn-prt-meds').trigger('click');
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\HMS\hms\resources\views/pages/receptionist/pritn_meds.blade.php ENDPATH**/ ?>